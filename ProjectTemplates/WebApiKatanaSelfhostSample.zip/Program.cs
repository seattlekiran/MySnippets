﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Hosting;
using System.Web.Http.Owin;
using Microsoft.Owin.Hosting;
using Owin;
using System.Threading.Tasks;
using System.Threading;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            string baseAddress = string.Format("http://{0}:9095", Environment.MachineName);

            using (WebApp.Start<Program>(url: baseAddress))
            {
                //HttpClient client = new HttpClient();
                //var response = client.GetAsync(baseAddress + "/api/values").Result;
                //Console.WriteLine(response.Content.ReadAsStringAsync().Result);

                Console.WriteLine("Listenting at {0}...", baseAddress);
                Console.ReadLine();
            }
        }

        public void Configuration(IAppBuilder appBuilder)
        {
            var config = new HttpConfiguration();

            config.MapHttpAttributeRoutes();

            appBuilder.UseWebApi(config);
        }
    }

    [RoutePrefix("api/values")]
    public class ValuesController : ApiController
    {
        [HttpGet("")]
        public IEnumerable<string> GetAll()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpGet("{id}")]
        public string GetSingle(int id)
        {
            return "value";
        }

        [HttpPost("")]
        public void Post([FromBody]string value)
        {
        }

        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

